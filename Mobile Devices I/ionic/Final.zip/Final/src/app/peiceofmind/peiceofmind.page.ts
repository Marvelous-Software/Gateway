import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-peiceofmind',
  templateUrl: './peiceofmind.page.html',
  styleUrls: ['./peiceofmind.page.scss'],
})
export class PeiceofmindPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
