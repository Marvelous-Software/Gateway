import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innocentexile',
  templateUrl: './innocentexile.page.html',
  styleUrls: ['./innocentexile.page.scss'],
})
export class InnocentexilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
