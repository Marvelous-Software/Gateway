import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-innocent-exile',
  templateUrl: './innocent-exile.page.html',
  styleUrls: ['./innocent-exile.page.scss'],
})
export class InnocentExilePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
