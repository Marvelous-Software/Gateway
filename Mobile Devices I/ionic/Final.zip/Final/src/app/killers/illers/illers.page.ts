import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-illers',
  templateUrl: './illers.page.html',
  styleUrls: ['./illers.page.scss'],
})
export class IllersPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
