import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-genghiskhan',
  templateUrl: './genghiskhan.page.html',
  styleUrls: ['./genghiskhan.page.scss'],
})
export class GenghiskhanPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
