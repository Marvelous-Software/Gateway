import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-killers',
  templateUrl: './killers.page.html',
  styleUrls: ['./killers.page.scss'],
})
export class KillersPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
