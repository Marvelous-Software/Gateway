import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wrathchild',
  templateUrl: './wrathchild.page.html',
  styleUrls: ['./wrathchild.page.scss'],
})
export class WrathchildPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
