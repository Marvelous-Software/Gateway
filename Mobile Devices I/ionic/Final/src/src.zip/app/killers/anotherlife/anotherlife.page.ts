import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-anotherlife',
  templateUrl: './anotherlife.page.html',
  styleUrls: ['./anotherlife.page.scss'],
})
export class AnotherlifePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
