import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-drifter',
  templateUrl: './drifter.page.html',
  styleUrls: ['./drifter.page.scss'],
})
export class DrifterPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
