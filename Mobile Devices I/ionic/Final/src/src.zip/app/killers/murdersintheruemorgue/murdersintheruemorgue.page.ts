import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-murdersintheruemorgue',
  templateUrl: './murdersintheruemorgue.page.html',
  styleUrls: ['./murdersintheruemorgue.page.scss'],
})
export class MurdersintheruemorguePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
