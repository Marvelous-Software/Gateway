import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theidesofmarch',
  templateUrl: './theidesofmarch.page.html',
  styleUrls: ['./theidesofmarch.page.scss'],
})
export class TheidesofmarchPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
