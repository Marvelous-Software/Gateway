import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-purgatory',
  templateUrl: './purgatory.page.html',
  styleUrls: ['./purgatory.page.scss'],
})
export class PurgatoryPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
