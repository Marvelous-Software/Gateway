import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prodigalson',
  templateUrl: './prodigalson.page.html',
  styleUrls: ['./prodigalson.page.scss'],
})
export class ProdigalsonPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
