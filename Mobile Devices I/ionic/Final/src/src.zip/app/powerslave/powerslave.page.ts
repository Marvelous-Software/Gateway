import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-powerslave',
  templateUrl: './powerslave.page.html',
  styleUrls: ['./powerslave.page.scss'],
})
export class PowerslavePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
