package com.example.mymusicapp

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast

class SongAdapter(songList: ArrayList<Song>) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    private val songList: ArrayList<Song>

    init{
        this.songList = songList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int ): SongViewHolder {
        val itemView: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.song_list_row, parent, false)
        return SongViewHolder(itemView)
    }

    override fun onBindViewHolder( holder: SongViewHolder, position: Int ) {

        holder.title.setText(songList[position].getTitle())
        holder.artist.setText(songList[position].getArtist())
        holder.genre.setText(songList[position].getGenre())

        holder.imageSong.setImageURI( Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                "://" +
                "com.example.mymusicapp/" +
                "drawable/" +
                songList[position].getImageSong() )
        )

    }

    override fun getItemCount(): Int {
        return songList.size
    }

    inner class SongViewHolder( view: View ) : RecyclerView.ViewHolder( view ){
        var title: TextView
        var artist: TextView
        var genre: TextView
        var imageSong: ImageView
        var song_row: ViewGroup

        val c: Context

        init{

            title = view.findViewById<TextView>(R.id.title)
            artist = view.findViewById<TextView>(R.id.artist)
            genre = view.findViewById<TextView>(R.id.genre)
            imageSong = view.findViewById(R.id.image_song) as ImageView

            c = view.context

            song_row = view.findViewById<ViewGroup>(R.id.song_row)
            addListenerToTitle()

        }

        fun addListenerToTitle() {
            song_row.setOnClickListener {
                Toast.makeText( c , "Title of the song was clicked!", Toast.LENGTH_LONG).show()
            }
        }
    }

}