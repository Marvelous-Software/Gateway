package com.example.navappclass.ui.songsearch

import androidx.lifecycle.ViewModel

class SongSearchViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
