package com.example.mymusicapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // creating a RecyclerView object
        val rView = findViewById<RecyclerView>(R.id.song_list)

        // the layoutManager is responsible of the layout of the page
        rView.layoutManager = LinearLayoutManager( this )

        // the adapter is responsible for the data to be displayed
        rView.adapter = SongAdapter( getListOfSongs() )


    }


    private fun getListOfSongs(): ArrayList<Song> {

        // declaring a list of Songs
        val songList = ArrayList<Song>()

        // populate the list of songs
        var song = Song( "The Box", "Roddy Ricch", "hip-hop")
        songList.add(song)

        return songList
    }

}
