package com.example.mymusicapp

import android.view.LayoutInflater
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup

class SongAdapter( songList: ArrayList<Song>) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    private val songList: ArrayList<Song>

    init{
        this.songList = songList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int ): SongViewHolder {
        val itemView: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.song_list_row, parent, false)
        return SongViewHolder(itemView)
    }

    override fun onBindViewHolder( holder: SongViewHolder, position: Int ) {
        holder.title.setText(songList[position].getTitle())
        holder.artist.setText(songList[position].getArtist())

    }

    override fun getItemCount(): Int {
        return songList.size
    }

    inner class SongViewHolder( view: View ) : RecyclerView.ViewHolder( view ){
        var title: TextView
        var artist: TextView

        init{
            title = view.findViewById<View>(R.id.title) as TextView
            artist = view.findViewById<View>(R.id.artist) as TextView
        }
    }

}