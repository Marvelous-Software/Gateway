package com.example.mymusicapp

import android.util.Log

class Song(title: String, artist: String, genre: String) {

    // properties
    private var title: String? = null
    private var artist: String? = null
    private var genre: String? = null
    private var length: Int? = null
    //var releaseDate

    init{
        this.title = title
        this.artist = artist
        this.genre = genre

        Log.v("From Song Class", "Song title: " + this.getTitle())

        // todo: complete the constructor
    }

    // methods
    fun changeTitle( title: String ){
        this.title = title
    }

    fun getTitle( ): String?{
        return title
    }

    fun changeArtist( artist: String ){
        this.artist = artist
    }

    fun getArtist( ): String?{
        return artist
    }

    fun changeGenre( genre: String ){
        this.genre = genre
    }

    fun getGenre( ): String?{
        return genre
    }
    // TODO: implement all the required methods

}