package com.example.mymusicapp

import android.content.ContentResolver
import android.net.Uri
import android.view.LayoutInflater
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.song_list_row.view.*

class SongAdapter(songList: ArrayList<Song>, private val clickListener: (Song) -> Unit) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    private val songList: ArrayList<Song>

    init{
        this.songList = songList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int ): SongViewHolder {
        val itemView: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.song_list_row, parent, false)
        return SongViewHolder(itemView)
    }

    override fun onBindViewHolder( holder: SongViewHolder, position: Int ) {

        holder.bind( songList[position], clickListener)

    }

    override fun getItemCount(): Int {
        return songList.size
    }

    inner class SongViewHolder( view: View ) : RecyclerView.ViewHolder( view ){

        fun bind(song: Song, clickListener: (Song) -> Unit) {
            itemView.title.text = song.getTitle()
            itemView.artist.text = song.getArtist()
            itemView.genre.text = song.getGenre()
            itemView.image_song.setImageURI( Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE +
                    "://" +
                    "com.example.mymusicapp/" +
                    "drawable/" +
                    song.getImageSong() ) )
            itemView.setOnClickListener { clickListener( song )}
        }


    }

}