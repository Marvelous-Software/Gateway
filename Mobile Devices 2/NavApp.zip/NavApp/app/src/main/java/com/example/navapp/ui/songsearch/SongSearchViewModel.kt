package com.example.navapp.ui.songsearch

import android.net.Uri
import android.util.Log
import android.widget.TextView
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject

class SongSearchViewModel : ViewModel() {
    private val _text = MutableLiveData<String>().apply {
        value = ""
    }


    var text: LiveData<String> = _text
}

