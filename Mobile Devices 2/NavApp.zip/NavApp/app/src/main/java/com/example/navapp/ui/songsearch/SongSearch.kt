package com.example.navapp.ui.songsearch

import android.net.Uri.encode
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.example.navapp.R
import kotlinx.android.synthetic.main.song_search_fragment.*
import org.json.JSONObject
import java.net.URLEncoder


class SongSearch : Fragment() {

    private lateinit var songSearchViewModel: SongSearchViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        songSearchViewModel = ViewModelProviders.of(this).get(SongSearchViewModel::class.java)
        val root = inflater.inflate(R.layout.song_search_fragment, container, false)

        val button: Button = root.findViewById(R.id.search_song_button) as Button
        button.setOnClickListener {

            val titleResults: TextView = root.findViewById(R.id.search_song_txt)
            songSearchViewModel.text.observe(viewLifecycleOwner, Observer {
                titleResults.text = "Showing just the first result:"
            })

            val searchTitle = root.findViewById<View>(R.id.textInputEditText) as EditText

            val song: TextView = root.findViewById(R.id.text_songsearch)

            song.onEditorAction(EditorInfo.IME_ACTION_DONE);

            loadSearch( song, searchTitle.text.toString() )
        }
        return root
    }

    fun loadSearch( textView: TextView, title: String ){

        val url = "https://ws.audioscrobbler.com/2.0/?method=track.search&track=" +
                encode( title ) +
                "&api_key=6de1dc611a0cbb962dac1683c9bea8fb&format=json"

        // Instantiate the RequestQueue.
        val queue = Volley.newRequestQueue( this.context  )

        // API response snippet
/*        {
            results: {
            opensearch:Query: {
            #text: "",
            role: "request",
            startPage: "1"
        },
            opensearch:totalResults: "685242",
            opensearch:startIndex: "0",
            opensearch:itemsPerPage: "30",
            trackmatches: {
            track: [
            {
                name: "Believer",
                artist: "Imagine Dragons",
                url: "https://www.last.fm/music/Imagine+Dragons/_/Believer",
                streamable: "FIXME",
                listeners: "358882",
                image: [
                {
                    #text: "https://lastfm.freetls.fastly.net/i/u/34s/2a96cbd8b46e442fc41c2b86b821562f.png",
                    size: "small"
                },
                {
                    #text: "https://lastfm.freetls.fastly.net/i/u/64s/2a96cbd8b46e442fc41c2b86b821562f.png",
                    size: "medium"
                },
                {
                    #text: "https://lastfm.freetls.fastly.net/i/u/174s/2a96cbd8b46e442fc41c2b86b821562f.png",
                    size: "large"
                },
                {
                    #text: "https://lastfm.freetls.fastly.net/i/u/300x300/2a96cbd8b46e442fc41c2b86b821562f.png",
                    size: "extralarge"
                }
                ],
                mbid: ""
            },*/

        // Request a string response from the provided URL.
        val request = JsonObjectRequest(
            Request.Method.GET, url, null,
            Response.Listener<JSONObject> { response ->
                var songInfo = response.getJSONObject("results")
                songInfo = songInfo.getJSONObject("trackmatches")
                val songInfos = songInfo.getJSONArray("track")

                songSearchViewModel.text.observe(viewLifecycleOwner, Observer {
                    textView.text = "Artist: " + songInfos.getJSONObject(0).getString("artist")
                })

            },
            Response.ErrorListener { error->
                Log.v("from SongDetails", "M: Exception: %s".format(error.toString()))
            })

        // Add the request to the RequestQueue.
        queue.add(request)


    }

}
