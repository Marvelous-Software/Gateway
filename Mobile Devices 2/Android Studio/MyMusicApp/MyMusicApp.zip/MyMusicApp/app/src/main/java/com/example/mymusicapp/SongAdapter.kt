package com.example.mymusicapp

import android.util.Log
import android.view.LayoutInflater
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.view.ViewGroup

class SongAdapter( songList: ArrayList<Song>) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    private val songList: ArrayList<Song>

    init{
        Log.v("init", "???")
        this.songList = songList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int ): SongViewHolder {
        Log.v("onCreateViewHolder", "Pre" + songList.size)
        val itemView: View = LayoutInflater.from(parent.context)
            .inflate(R.layout.song_list_row, parent, false)
        Log.v("onCreateViewHolder", "First" + songList.size)

        return SongViewHolder(itemView)
    }

    override fun onBindViewHolder( holder: SongViewHolder, position: Int ) {

        Log.v("onBindViewHolder", "" + position)

        holder.title.setText(songList[position].getTitle())
        holder.artist.setText(songList[position].getArtist())
        holder.genre.setText(songList[position].getGenre())

    }

    override fun getItemCount(): Int {
        Log.v("getItemCount", "" + songList.size)

        return songList.size
    }

    inner class SongViewHolder( view: View ) : RecyclerView.ViewHolder( view ){
        var title: TextView
        var artist: TextView
        var genre: TextView

        init{
            Log.v("SongViewHolder", "init")

            this.title = view.findViewById<View>(R.id.title) as TextView
            this.artist = view.findViewById<View>(R.id.artist) as TextView
            this.genre = view.findViewById<View>(R.id.genre) as TextView
        }
    }

}